<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

<div class="coloumn">
    <div class="row">
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Anak anda hilang?</h5>
                    <p class="card-text">Ada seorang anak yang diculik!</p>
                    <a href="https://www.youtube.com/watch?v=6OtPSfyZXNw" class="btn btn-primary">Lihat Video</a>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Pergi ke Posyandu</h5>
                    <p class="card-text">Ada cerita bayi pergi ke posyandu</p>
                    <a href="https://www.youtube.com/watch?v=6OtPSfyZXNw" class="btn btn-primary">Lihat Video</a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Ukuran kepala itu penting?</h5>
                    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    <a href="https://www.youtube.com/watch?v=6OtPSfyZXNw" class="btn btn-primary">Lihat Video</a>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Jangan sampai anak anda tumbuh ke samping</h5>
                    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    <a href="https://www.youtube.com/watch?v=6OtPSfyZXNw" class="btn btn-primary">Lihat Video</a>
                </div>
            </div>
        </div>
    </div>
</div>